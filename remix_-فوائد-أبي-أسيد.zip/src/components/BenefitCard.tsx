import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Eye, Share2, Edit, Trash, Copy, Check, ChevronDown, ChevronUp, BookOpen, Calendar, Tag } from 'lucide-react';
import { Benefit } from '../types';
import { formatToHijriAndGregorian } from '../utils';

interface BenefitCardProps {
  benefit: Benefit;
  onView: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onEdit: (benefit: Benefit) => void;
  onDelete: (id: string) => void;
  showToast: (msg: string, type: 'success' | 'info' | 'warning') => void;
}

export const BenefitCard: React.FC<BenefitCardProps> = ({
  benefit,
  onView,
  onToggleFavorite,
  onEdit,
  onDelete,
  showToast,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const handleCardClick = () => {
    if (!isExpanded) {
      onView(benefit.id); // Register a view in state
    }
    setIsExpanded(!isExpanded);
  };

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    const textToShare = `📖 فائدة علمية من: [جامع الفوائد]\n\nالعنوان: ${benefit.title}\nالتصنيف: ${benefit.category}\nالمصدر: ${benefit.source || 'غير محدد'}\nالتاريخ: ${formatToHijriAndGregorian(benefit.date)}\n\nالنص:\n"${benefit.content}"`;
    
    navigator.clipboard.writeText(textToShare);
    setCopied(true);
    showToast('تم نسخ الفائدة بالكامل لمشاركتها مع من تحب!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const textToShare = `📖 فائدة علمية من: [فوائد أبي أسيد]\n\nالعنوان: ${benefit.title}\nالتصنيف: ${benefit.category}\n\n"${benefit.content}"`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: benefit.title,
          text: textToShare,
        });
        showToast('تمت المشاركة بنجاح!', 'success');
      } catch (err) {
        // Fallback if dismissed or failed
        handleCopy(e);
      }
    } else {
      handleCopy(e);
    }
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    onDelete(benefit.id);
    showToast('تم حذف الفائدة العلمية بنجاح.', 'info');
    setShowDeleteModal(false);
  };

  return (
    <>
      <motion.div
        layout
        className={`bg-white rounded-2xl border border-zinc-200 overflow-hidden cursor-pointer transition-all duration-300 custom-shadow hover:border-brand-cream text-right relative ${
          isExpanded ? 'border-brand-gold/40 ring-1 ring-brand-gold/15' : ''
        }`}
        onClick={handleCardClick}
      >
        {/* Card Header area */}
        <div className="p-5 space-y-3">
          {/* Top row metadata badges and icons */}
          <div className="flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 bg-brand-cream/40 text-brand-emerald font-bold rounded-lg flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-brand-gold shrink-0" />
                {benefit.category}
              </span>
              
              {benefit.source && (
                <span className="text-zinc-500 font-sans truncate max-w-[150px] sm:max-w-xs font-medium">
                  المصدر: {benefit.source}
                </span>
              )}
            </div>

            {/* Quick Action Favorites Heart */}
            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleFavorite(benefit.id);
                  showToast(benefit.isFavorite ? 'تمت الإزالة من المفضلة.' : 'تمت الإضافة للمفضلة!', 'success');
                }}
                className="p-1.5 rounded-lg hover:bg-zinc-100 transition-all text-zinc-400 hover:text-red-500"
              >
                <Heart
                  className={`w-4 h-4 transition-all ${
                    benefit.isFavorite ? 'fill-red-500 text-red-500 scale-110' : ''
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Title and views counter */}
          <div className="flex items-start justify-between gap-4">
            <h3 className="text-base sm:text-lg font-bold text-brand-emerald-dark font-sans leading-snug">
              {benefit.title}
            </h3>
            
            <div className="flex items-center gap-1.5 text-zinc-400 font-sans text-xs pt-1 shrink-0">
              <Eye className="w-3.5 h-3.5 text-zinc-400" />
              <span>{benefit.views}</span>
            </div>
          </div>

          {/* Summarized preview text if collapsed */}
          {!isExpanded && (
            <p className="text-sm text-zinc-600 line-clamp-2 leading-relaxed font-serif pt-1">
              {benefit.content}
            </p>
          )}

          {/* Expanded full body content */}
          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden pt-2 border-t border-brand-cream/20 mt-3"
              >
                <p className="text-base text-zinc-800 font-serif leading-loose whitespace-pre-line bg-brand-beige/40 p-4 rounded-xl border border-brand-cream/30 select-text">
                  {benefit.content}
                </p>

                {/* Date & Metadata footer */}
                <div className="flex flex-wrap items-center justify-between gap-4 pt-4 mt-2 text-xs border-t border-zinc-100 text-zinc-500">
                  <div className="flex items-center gap-1.5 font-sans">
                    <Calendar className="w-4 h-4 text-brand-gold" />
                    <span>تاريخ التدوين: {formatToHijriAndGregorian(benefit.date)}</span>
                  </div>

                  {/* Operational Toolbar */}
                  <div className="flex items-center gap-1.5">
                    {/* Share Button */}
                    <button
                      onClick={handleShare}
                      className="px-3 py-1.5 rounded-lg hover:bg-zinc-100 text-zinc-600 font-sans flex items-center gap-1.5 transition-all text-xs border border-zinc-200"
                      title="مشاركة الفائدة"
                    >
                      <Share2 className="w-3.5 h-3.5 text-brand-gold" />
                      <span>مشاركة ونشر</span>
                    </button>

                    {/* Copy Button */}
                    <button
                      onClick={handleCopy}
                      className="px-3 py-1.5 rounded-lg hover:bg-zinc-100 text-zinc-600 font-sans flex items-center gap-1.5 transition-all text-xs border border-zinc-200"
                      title="نسخ النص"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-600">تم النسخ</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-brand-emerald" />
                          <span>نسخ سريع</span>
                        </>
                      )}
                    </button>

                    {/* Edit Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onEdit(benefit);
                      }}
                      className="px-3 py-1.5 rounded-lg hover:bg-brand-cream/30 text-brand-emerald hover:text-brand-emerald-dark font-sans flex items-center gap-1 transition-all text-xs border border-brand-cream/60"
                      title="تعديل الفائدة"
                    >
                      <Edit className="w-3.5 h-3.5 text-brand-gold" />
                      <span>تعديل</span>
                    </button>

                    {/* Delete Button */}
                    <button
                      onClick={handleDelete}
                      className="px-3 py-1.5 rounded-lg hover:bg-red-50 text-red-600 font-sans flex items-center gap-1 transition-all text-xs border border-red-100"
                      title="حذف الفائدة"
                    >
                      <Trash className="w-3.5 h-3.5" />
                      <span>حذف</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Toggle Expand visual indicator bar */}
          <div className="flex justify-center pt-2 text-zinc-400 hover:text-brand-emerald transition-colors">
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </div>
      </motion.div>

      {/* Delete Confirmation Popup */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-2xl max-w-sm w-full p-6 text-right font-sans border border-brand-cream/60 custom-shadow"
            >
              <h4 className="text-base font-bold text-zinc-800 mb-2">تأكيد حذف الفائدة العلمية</h4>
              <p className="text-xs text-zinc-500 leading-relaxed mb-6">
                هل أنت متأكد من رغبتك في حذف الفائدة بعنوان: "{benefit.title}"؟ سيتم حذف هذه المسألة نهائياً ولا يمكن استرجاعها.
              </p>
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => setShowDeleteModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-zinc-500 hover:bg-zinc-100 rounded-xl transition-all"
                >
                  إلغاء التراجع
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 text-xs font-bold bg-red-600 text-white rounded-xl hover:bg-red-700 transition-all"
                >
                  نعم، احذف الفائدة
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
